package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05070F"))
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S"; textSize = 32f; setTextColor(Color.parseColor("#00E5FF"))
        })
        status = TextView(this).apply {
            textSize = 15f; setTextColor(Color.parseColor("#8FA8B8")); setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(status)

        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label; setTextColor(Color.parseColor("#00E5FF"))
                setBackgroundColor(Color.parseColor("#0B1E2D")); setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }

        button("1. Microphone permission do") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
        button("2. Overlay (floating button) permission do") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("3. Battery: JARVIS ko 'No restrictions' do") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        button("4. App settings (Autostart/Background yahin se)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        button("▶ JARVIS CHALU KARO") {
            if (!Settings.canDrawOverlays(this)) toast("Pehle step 2 karo")
            else if (!micOk()) toast("Pehle step 1 karo")
            else { startForegroundService(Intent(this, OverlayService::class.java)); toast("Right edge par J button dekho") }
        }
        button("■ JARVIS BAND KARO") { stopService(Intent(this, OverlayService::class.java)) }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = "Mic permission: ${if (micOk()) "✔" else "✘"}\nOverlay permission: ${if (Settings.canDrawOverlays(this)) "✔" else "✘"}"
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g); onResume()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
