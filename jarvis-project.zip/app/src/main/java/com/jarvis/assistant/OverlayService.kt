package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var btn: TextView
    private lateinit var tab: View
    private lateinit var lp: WindowManager.LayoutParams
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val ui = Handler(Looper.getMainLooper())
    private val cyan = Color.parseColor("#00E5FF")
    private val dark = Color.parseColor("#0A1320")
    private val red = Color.parseColor("#FF3D71")

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                tts?.setPitch(0.75f)
                try {
                    tts?.voices?.filter { it.locale.language == "hi" }
                        ?.firstOrNull { val n = it.name.lowercase(); n.contains("male") && !n.contains("female") }
                        ?.let { tts?.voice = it }
                } catch (_: Exception) {}
            }
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "JARVIS", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("JARVIS active")
            .setContentText("Floating button chalu hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        try {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            try { startForeground(1, n) } catch (e2: Exception) { stopSelf() }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, stroke: Int, radius: Float, type: Int = GradientDrawable.RECTANGLE) =
        GradientDrawable().apply {
            shape = type; setColor(fill); setStroke(dp(2), stroke); cornerRadius = radius
        }

    private fun draggable(v: View, onTap: () -> Unit) {
        var sx = 0; var sy = 0; var rx = 0f; var ry = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; rx = e.rawX; ry = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - rx; val dy = e.rawY - ry
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moved = true
                    if (moved) {
                        lp.x = (sx - dx).toInt().coerceAtLeast(0)
                        lp.y = (sy + dy).toInt().coerceAtLeast(0)
                        wm.updateViewLayout(root, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap()
            }
            true
        }
    }

    private fun item(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(cyan); setPadding(dp(14), dp(10), dp(14), dp(10))
        setOnClickListener { onClick() }
    }

    private fun buildOverlay() {
        root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(dark, cyan, dp(12).toFloat())
            visibility = View.GONE
        }
        panel.addView(item("▶  START") { panel.visibility = View.GONE; startListening() })
        panel.addView(item("◀  HIDE") { panel.visibility = View.GONE; btn.visibility = View.GONE; tab.visibility = View.VISIBLE })
        panel.addView(item("✖  OFF") { stopSelf() })

        btn = TextView(this).apply {
            text = "J"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(cyan)
            background = shape(dark, cyan, 0f, GradientDrawable.OVAL)
        }
        tab = View(this).apply {
            background = shape(cyan, cyan, dp(5).toFloat()); visibility = View.GONE
        }

        root.addView(panel, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        root.addView(btn, LinearLayout.LayoutParams(dp(56), dp(56)))
        root.addView(tab, LinearLayout.LayoutParams(dp(10), dp(80)))

        draggable(btn) { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        draggable(tab) { tab.visibility = View.GONE; btn.visibility = View.VISIBLE }

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 0; y = dp(300) }
        wm.addView(root, lp)
    }

    private fun setListening(on: Boolean) {
        btn.text = if (on) "●" else "J"
        btn.setTextColor(if (on) red else cyan)
        btn.background = shape(dark, if (on) red else cyan, 0f, GradientDrawable.OVAL)
    }

    private fun say(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun startListening() {
        tts?.stop()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("इस फ़ोन में स्पीच रिकग्निशन उपलब्ध नहीं है. Google app अपडेट करें."); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { setListening(true); Toast.makeText(this@OverlayService, "सुन रहा हूँ...", Toast.LENGTH_SHORT).show() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { setListening(false) }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) {
                setListening(false)
                say(when (e) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "आवाज़ समझ नहीं आई, फिर से बोलिए."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक्रोफ़ोन की अनुमति नहीं है."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "इंटरनेट की समस्या है."
                    else -> "कुछ गड़बड़ हुई, कोड $e."
                })
            }
            override fun onResults(r: Bundle?) {
                setListening(false)
                val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) { say("कुछ सुनाई नहीं दिया."); return }
                Toast.makeText(this@OverlayService, "\"$text\"", Toast.LENGTH_SHORT).show()
                say(CommandHandler(this@OverlayService).handle(text))
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(i)
    }

    override fun onDestroy() {
        try { wm.removeView(root) } catch (_: Exception) {}
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
