package com.jarvis.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock

class CommandHandler(private val ctx: Context) {

    private val multi = listOf(
        "प्ले स्टोर" to "play store", "यू ट्यूब" to "youtube", "व्हाट्स ऐप" to "whatsapp"
    )
    private val dev = mapOf(
        "यूट्यूब" to "youtube", "खोलो" to "kholo", "खोलिए" to "kholo", "खोल" to "kholo", "ओपन" to "open",
        "सर्च" to "search", "खोजो" to "search", "करो" to "karo", "पर" to "par", "टाइमर" to "timer",
        "अलार्म" to "alarm", "लगाओ" to "lagao", "लगा" to "lagao", "बजे" to "baje", "मिनट" to "minute",
        "सेकंड" to "second", "घंटे" to "ghante", "घंटा" to "ghante", "सुबह" to "subah", "शाम" to "shaam",
        "रात" to "raat", "दोपहर" to "dopahar", "साढ़े" to "sade", "साढे" to "sade", "बंद" to "band",
        "रोक" to "band", "खबर" to "khabar", "खबरें" to "khabar", "समाचार" to "samachar", "न्यूज़" to "news",
        "न्यूज" to "news", "इंस्टाग्राम" to "instagram", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "कैमरा" to "camera", "सेटिंग्स" to "settings", "सेटिंग" to "settings", "क्रोम" to "chrome",
        "इंस्टॉल" to "install", "अनइंस्टॉल" to "uninstall", "जार्विस" to "jarvis", "जारविस" to "jarvis",
        "चालू" to "chalu", "चलाओ" to "chalao"
    )
    private val numWords = mapOf(
        "ek" to 1, "एक" to 1, "do" to 2, "दो" to 2, "teen" to 3, "तीन" to 3, "char" to 4, "चार" to 4,
        "paanch" to 5, "panch" to 5, "पांच" to 5, "पाँच" to 5, "chhe" to 6, "che" to 6, "chah" to 6, "छह" to 6, "छः" to 6,
        "saat" to 7, "सात" to 7, "aath" to 8, "आठ" to 8, "nau" to 9, "नौ" to 9, "das" to 10, "दस" to 10,
        "gyarah" to 11, "ग्यारह" to 11, "barah" to 12, "बारह" to 12, "pandrah" to 15, "पंद्रह" to 15,
        "bees" to 20, "बीस" to 20, "tees" to 30, "तीस" to 30, "paintalis" to 45, "पैंतालीस" to 45
    )

    private fun normalize(raw: String): String {
        var s = raw.lowercase()
        for ((a, b) in "०१२३४५६७८९".zip("0123456789")) s = s.replace(a, b)
        for ((a, b) in multi) s = s.replace(a, b)
        s = s.replace(Regex("[,?!।]"), " ")
        return s.split(Regex("\\s+")).filter { it.isNotBlank() }.joinToString(" ") { dev[it] ?: it }
    }

    private fun strip(t: String, stop: Set<String>) =
        t.split(" ").filter { it.isNotBlank() && it !in stop }.joinToString(" ")

    private fun firstNumber(t: String): Int? {
        Regex("\\d+").find(t)?.let { return it.value.toInt() }
        return t.split(" ").firstNotNullOfOrNull { numWords[it] }
    }

    private fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }

    fun handle(raw: String): String {
        val t = normalize(raw)
        fun has(vararg k: String) = k.any { t.contains(it) }
        return try {
            when {
                has("timer") -> timer(t)
                has("alarm") -> alarm(t)
                has("youtube") -> youtube(t)
                has("uninstall") -> uninstall(t)
                has("install") -> install(t)
                has("news", "khabar", "samachar") -> news(t)
                has("kholo", "open", "chalu", "chalao") -> openApp(t)
                else -> {
                    googleSearch(strip(t, setOf("jarvis")))
                    "इसका जवाब देने वाला AI अभी जुड़ा नहीं है, इसलिए Google पर खोज रहा हूँ."
                }
            }
        } catch (e: Exception) {
            "यह काम नहीं हो पाया: ${e.javaClass.simpleName}"
        }
    }

    private fun timer(t: String): String {
        if (t.contains("band") || t.contains("stop") || t.contains("cancel") || t.contains("hata")) {
            go(Intent(AlarmClock.ACTION_DISMISS_TIMER))
            return "टाइमर बंद करने की कोशिश कर रहा हूँ. अगर बंद न हो, तो Clock ऐप में बंद करें."
        }
        val n = firstNumber(t) ?: return "कितने समय का टाइमर? जैसे, 10 मिनट का टाइमर लगाओ."
        val secs = when {
            t.contains("ghant") || t.contains("hour") -> n * 3600
            t.contains("second") || t.contains("sec") -> n
            else -> n * 60
        }.coerceAtMost(86400)
        go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "ठीक है, टाइमर लगा दिया."
    }

    private fun alarm(t: String): String {
        var h: Int; var m = 0
        val hm = Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(t)
        if (hm != null) { h = hm.groupValues[1].toInt(); m = hm.groupValues[2].toInt() }
        else { h = firstNumber(t) ?: return "कितने बजे का अलार्म? जैसे, सुबह 6 बजे का अलार्म लगाओ." ; if (t.contains("sade")) m = 30 }
        val pm = t.contains("shaam") || t.contains("raat") || t.contains(" pm")
        val noon = t.contains("dopahar")
        if (pm && h < 12) h += 12
        if (noon && h in 1..6) h += 12
        if (t.contains("subah") && h == 12) h = 0
        if (h > 23 || m > 59) return "समय सही नहीं लगा, फिर से बोलिए."
        go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "अलार्म $h बजकर $m मिनट के लिए लगा दिया."
    }

    private fun youtube(t: String): String {
        val q = strip(t, setOf("youtube", "jarvis", "par", "pe", "search", "karo", "kholo", "open", "lagao", "dikhao", "on"))
        if (q.isBlank()) {
            val i = ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            go(i); return "यूट्यूब खोल रहा हूँ."
        }
        val u = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
        try { go(Intent(Intent.ACTION_VIEW, u).setPackage("com.google.android.youtube")) }
        catch (e: ActivityNotFoundException) { go(Intent(Intent.ACTION_VIEW, u)) }
        return "यूट्यूब पर $q खोज रहा हूँ."
    }

    private fun findApp(name: String): Pair<String, String>? {
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { pm.getApplicationLabel(it).toString() to it.packageName }
        val n = name.lowercase()
        return apps.firstOrNull { it.first.lowercase() == n }
            ?: apps.firstOrNull { it.first.lowercase().contains(n) }
            ?: apps.firstOrNull { n.contains(it.first.lowercase()) && it.first.length > 2 }
    }

    private fun openApp(t: String): String {
        val name = strip(t, setOf("kholo", "open", "karo", "chalu", "chalao", "jarvis", "app", "ko", "please"))
        if (name.isBlank()) return "कौन सा ऐप खोलूँ?"
        val app = findApp(name) ?: return "$name नाम का ऐप नहीं मिला."
        go(ctx.packageManager.getLaunchIntentForPackage(app.second)!!)
        return "${app.first} खोल रहा हूँ."
    }

    private fun install(t: String): String {
        val name = strip(t, setOf("install", "karo", "jarvis", "app", "download", "ko", "kholo", "lagao"))
        try { go(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(name)))) }
        catch (e: ActivityNotFoundException) { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(name)))) }
        return "प्ले स्टोर में $name खोल रहा हूँ. Install आप खुद दबाइए."
    }

    private fun uninstall(t: String): String {
        val name = strip(t, setOf("uninstall", "karo", "jarvis", "app", "ko", "hatao", "delete"))
        val app = findApp(name) ?: return "$name नाम का ऐप नहीं मिला."
        go(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.second)))
        return "${app.first} की अनइंस्टॉल स्क्रीन खुल गई है, वहाँ OK दबाइए."
    }

    private fun news(t: String): String {
        val q = strip(t, setOf("jarvis", "batao", "bataiye", "dikhao"))
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?tbm=nws&q=" + Uri.encode(q))))
        return "Google News में खबरें खोल रहा हूँ."
    }

    private fun googleSearch(q: String) {
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
    }
}
